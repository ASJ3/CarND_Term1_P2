
# Self-Driving Car Engineer Nanodegree

## Deep Learning

## Project: Build a Traffic Sign Recognition Classifier

In this notebook, a template is provided for you to implement your functionality in stages, which is required to successfully complete this project. If additional code is required that cannot be included in the notebook, be sure that the Python code is successfully imported and included in your submission if necessary. 

> **Note**: Once you have completed all of the code implementations, you need to finalize your work by exporting the iPython Notebook as an HTML document. Before exporting the notebook to html, all of the code cells need to have been run so that reviewers can see the final implementation and output. You can then export the notebook by using the menu above and navigating to  \n",
    "**File -> Download as -> HTML (.html)**. Include the finished document along with this notebook as your submission. 

In addition to implementing code, there is a writeup to complete. The writeup should be completed in a separate file, which can be either a markdown file or a pdf document. There is a [write up template](https://github.com/udacity/CarND-Traffic-Sign-Classifier-Project/blob/master/writeup_template.md) that can be used to guide the writing process. Completing the code template and writeup template will cover all of the [rubric points](https://review.udacity.com/#!/rubrics/481/view) for this project.

The [rubric](https://review.udacity.com/#!/rubrics/481/view) contains "Stand Out Suggestions" for enhancing the project beyond the minimum requirements. The stand out suggestions are optional. If you decide to pursue the "stand out suggestions", you can include the code in this Ipython notebook and also discuss the results in the writeup file.


>**Note:** Code and Markdown cells can be executed using the **Shift + Enter** keyboard shortcut. In addition, Markdown cells can be edited by typically double-clicking the cell to enter edit mode.

---
## Step 0: Load The Data


```python
# Load pickled data
import pickle

# TODO: Fill this in based on where you saved the training and testing data

training_file = 'train.p'
validation_file= 'valid.p'
testing_file =  'test.p'

with open(training_file, mode='rb') as f:
    train = pickle.load(f)
with open(validation_file, mode='rb') as f:
    valid = pickle.load(f)
with open(testing_file, mode='rb') as f:
    test = pickle.load(f)
    
X_train_orig, y_train = train['features'], train['labels']
X_validation_orig, y_validation = valid['features'], valid['labels']
X_test_orig, y_test = test['features'], test['labels']
```

---

## Step 1: Dataset Summary & Exploration

The pickled data is a dictionary with 4 key/value pairs:

- `'features'` is a 4D array containing raw pixel data of the traffic sign images, (num examples, width, height, channels).
- `'labels'` is a 1D array containing the label/class id of the traffic sign. The file `signnames.csv` contains id -> name mappings for each id.
- `'sizes'` is a list containing tuples, (width, height) representing the original width and height the image.
- `'coords'` is a list containing tuples, (x1, y1, x2, y2) representing coordinates of a bounding box around the sign in the image. **THESE COORDINATES ASSUME THE ORIGINAL IMAGE. THE PICKLED DATA CONTAINS RESIZED VERSIONS (32 by 32) OF THESE IMAGES**

Complete the basic data summary below. Use python, numpy and/or pandas methods to calculate the data summary rather than hard coding the results. For example, the [pandas shape method](http://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.shape.html) might be useful for calculating some of the summary results. 

### Provide a Basic Summary of the Data Set Using Python, Numpy and/or Pandas


```python
### Replace each question mark with the appropriate value. 
### Use python, pandas or numpy methods rather than hard coding the results

# TODO: Number of training examples
n_train = len(X_train_orig)

# TODO: Number of validation examples
n_validation = len(X_validation_orig)

# TODO: Number of testing examples.
n_test = len(X_test_orig)

# TODO: What's the shape of an traffic sign image?
image_shape = X_train_orig[0].shape

# TODO: How many unique classes/labels there are in the dataset.
# each label value in the y_train dataset corresponds to a class. 
unique_class_values = set(y_train)
n_classes = len(unique_class_values)
print("Number of training examples =", n_train)
print("Number of validation examples =", n_validation)
print("Number of testing examples =", n_test)

print("Image data shape =", image_shape)
#print("Values of classes =", v_classes)
print("Number of classes =", n_classes)


```

    Number of training examples = 34799
    Number of validation examples = 4410
    Number of testing examples = 12630
    Image data shape = (32, 32, 3)
    Number of classes = 43


### Include an exploratory visualization of the dataset

Visualize the German Traffic Signs Dataset using the pickled file(s). This is open ended, suggestions include: plotting traffic sign images, plotting the count of each sign, etc. 

The [Matplotlib](http://matplotlib.org/) [examples](http://matplotlib.org/examples/index.html) and [gallery](http://matplotlib.org/gallery.html) pages are a great resource for doing visualizations in Python.

**NOTE:** It's recommended you start with something simple first. If you wish to do more, come back to it after you've completed the rest of the sections. It can be interesting to look at the distribution of classes in the training, validation and test set. Is the distribution the same? Are there more examples of some classes than others?


```python
### Data exploration visualization code goes here.
### Feel free to use as many code cells as needed.
import random
import matplotlib.pyplot as plt

index = random.randint(0, len(X_train_orig))
image = X_train_orig[index]

# Visualizations will be shown in the notebook.
%matplotlib inline

print("\n# of the random picture chosen in the set: ", index)
plt.figure(figsize=(1,1))
plt.imshow(image)
print("Class # of picture chosen: ", y_train[index])
```

    
    # of the random picture chosen in the set:  22614
    Class # of picture chosen:  13



![png](output_8_1.png)


----

## Step 2: Design and Test a Model Architecture

Design and implement a deep learning model that learns to recognize traffic signs. Train and test your model on the [German Traffic Sign Dataset](http://benchmark.ini.rub.de/?section=gtsrb&subsection=dataset).

The LeNet-5 implementation shown in the [classroom](https://classroom.udacity.com/nanodegrees/nd013/parts/fbf77062-5703-404e-b60c-95b78b2f3f9e/modules/6df7ae49-c61c-4bb2-a23e-6527e69209ec/lessons/601ae704-1035-4287-8b11-e2c2716217ad/concepts/d4aca031-508f-4e0b-b493-e7b706120f81) at the end of the CNN lesson is a solid starting point. You'll have to change the number of classes and possibly the preprocessing, but aside from that it's plug and play! 

With the LeNet-5 solution from the lecture, you should expect a validation set accuracy of about 0.89. To meet specifications, the validation set accuracy will need to be at least 0.93. It is possible to get an even higher accuracy, but 0.93 is the minimum for a successful project submission. 

There are various aspects to consider when thinking about this problem:

- Neural network architecture (is the network over or underfitting?)
- Play around preprocessing techniques (normalization, rgb to grayscale, etc)
- Number of examples per label (some have more than others).
- Generate fake data.

Here is an example of a [published baseline model on this problem](http://yann.lecun.com/exdb/publis/pdf/sermanet-ijcnn-11.pdf). It's not required to be familiar with the approach used in the paper but, it's good practice to try to read papers like these.

### Pre-process the Data Set (normalization, grayscale, etc.)

Minimally, the image data should be normalized so that the data has mean zero and equal variance. For image data, `(pixel - 128)/ 128` is a quick way to approximately normalize the data and can be used in this project. 

Other pre-processing steps are optional. You can try different techniques to see if it improves performance. 

Use the code cell (or multiple code cells, if necessary) to implement the first step of your project.


```python
import numpy as np
from sklearn.utils import shuffle

# normalize() is designed to normalize an array of pictures so instead of having an array of values between 0...255
# it is centered around 0 with values between -1 and 1
def normalize(image_array):
    normalizer = np.array([128,128,128])
    image_array = np.subtract(image_array, normalizer)
    image_array = np.divide(image_array, normalizer)
    image_array = image_array.astype(np.float32)
    return image_array

# Normalizing all our sets of image arrays (training, validation and testing sets)
X_train = normalize(X_train_orig)
X_validation =  normalize(X_validation_orig)
X_test = normalize(X_test_orig)

"""
# Checking a 'pixel' value inside an image is now a flow number
print(X_train_orig[2369][5][8][0])
print(type(X_train_orig[2369][5][8][0]))
print(X_train[2369][5][8][0])
print(type(X_train[2369][5][8][0]))
"""

# Shuffle the train data in order to avoid having the same categories in a batch 
# in case the original data was not shuffled already
X_train, y_train = shuffle(X_train, y_train)
```

### Model Architecture


```python
import tensorflow as tf

EPOCHS = 30
BATCH_SIZE = 128
```


```python
from tensorflow.contrib.layers import flatten

def LeNet(x):    
    # Arguments used for tf.truncated_normal, randomly defines variables for the weights and biases for each layer
    mu = 0
    sigma = 0.1
    
    # SOLUTION: Layer 1: Convolutional. Input = 32x32x3. Output = 32x32x6.
    conv1_W = tf.Variable(tf.truncated_normal(shape=(5, 5, 3, 6), mean = mu, stddev = sigma))
    conv1_b = tf.Variable(tf.zeros(6))
    conv1   = tf.nn.conv2d(x, conv1_W, strides=[1, 1, 1, 1], padding='VALID') + conv1_b

    # SOLUTION: Activation.
    conv1 = tf.nn.relu(conv1)

    # SOLUTION: Pooling. Input = 28x28x6. Output = 14x14x6.
    conv1 = tf.nn.max_pool(conv1, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='VALID')

    # SOLUTION: Layer 2: Convolutional. Output = 10x10x16.
    conv2_W = tf.Variable(tf.truncated_normal(shape=(5, 5, 6, 16), mean = mu, stddev = sigma))
    conv2_b = tf.Variable(tf.zeros(16))
    conv2   = tf.nn.conv2d(conv1, conv2_W, strides=[1, 1, 1, 1], padding='VALID') + conv2_b
    
    # SOLUTION: Activation.
    conv2 = tf.nn.relu(conv2)

    # SOLUTION: Pooling. Input = 10x10x16. Output = 5x5x16.
    conv2 = tf.nn.max_pool(conv2, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='VALID')

    # SOLUTION: Flatten. Input = 5x5x16. Output = 400.
    fc0   = flatten(conv2)
    
    # SOLUTION: Layer 3: Fully Connected. Input = 400. Output = 120.
    fc1_W = tf.Variable(tf.truncated_normal(shape=(400, 120), mean = mu, stddev = sigma))
    fc1_b = tf.Variable(tf.zeros(120))
    fc1   = tf.matmul(fc0, fc1_W) + fc1_b
    
    # SOLUTION: Activation.
    fc1    = tf.nn.relu(fc1)

    # SOLUTION: Layer 4: Fully Connected. Input = 120. Output = 84.
    fc2_W  = tf.Variable(tf.truncated_normal(shape=(120, 84), mean = mu, stddev = sigma))
    fc2_b  = tf.Variable(tf.zeros(84))
    fc2    = tf.matmul(fc1, fc2_W) + fc2_b
    
    # SOLUTION: Activation.
    fc2    = tf.nn.relu(fc2)

    # SOLUTION: Layer 5: Fully Connected. Input = 84. Output = 43 (43 traffic signs categories).
    fc3_W  = tf.Variable(tf.truncated_normal(shape=(84, 43), mean = mu, stddev = sigma))
    fc3_b  = tf.Variable(tf.zeros(43))
    logits = tf.matmul(fc2, fc3_W) + fc3_b
    
    return logits
```

## Train, Validate and Test the Model

A validation set can be used to assess how well the model is performing. A low accuracy on the training and validation
sets imply underfitting. A high accuracy on the training set but low accuracy on the validation set implies overfitting.

### Features and Labels


```python
x = tf.placeholder(tf.float32, (None, 32, 32, 3))
y = tf.placeholder(tf.int32, (None))
one_hot_y = tf.one_hot(y, 43)
```

### Training Pipeline


```python
# Creating two learning rates
# the smaller learning rates will be used after a certain number of epochs, to avoid divergence
rate = 0.001
rate_small = 0.0001

logits = LeNet(x)
cross_entropy = tf.nn.softmax_cross_entropy_with_logits(labels=one_hot_y, logits=logits)
loss_operation = tf.reduce_mean(cross_entropy)
optimizer = tf.train.AdamOptimizer(learning_rate = rate)
optimizer_small = tf.train.AdamOptimizer(learning_rate = rate_small)
training_operation = optimizer.minimize(loss_operation)
training_operation_small = optimizer_small.minimize(loss_operation)
```

### Model Evaluation


```python
correct_prediction = tf.equal(tf.argmax(logits, 1), tf.argmax(one_hot_y, 1))
accuracy_operation = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
saver = tf.train.Saver()

def evaluate(X_data, y_data):
    num_examples = len(X_data)
    total_accuracy = 0
    sess = tf.get_default_session()
    for offset in range(0, num_examples, BATCH_SIZE):
        batch_x, batch_y = X_data[offset:offset+BATCH_SIZE], y_data[offset:offset+BATCH_SIZE]
        accuracy = sess.run(accuracy_operation, feed_dict={x: batch_x, y: batch_y})
        total_accuracy += (accuracy * len(batch_x))
    return total_accuracy / num_examples
```

### Training / Validating the Model


```python
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    num_examples = len(X_train)
    
    print("Training...")
    print()
    for i in range(EPOCHS):
        printed_count = 0
        X_train, y_train = shuffle(X_train, y_train)
        for offset in range(0, num_examples, BATCH_SIZE):
            end = offset + BATCH_SIZE
            batch_x, batch_y = X_train[offset:end], y_train[offset:end]
            if i < 26:
                if printed_count < 1:
                    print("This is EPOCH", i+1)
                    printed_count = 1
                
                sess.run(training_operation, feed_dict={x: batch_x, y: batch_y})
            else:
                if printed_count < 1:
                    print("Small learning rate: EPOCH", i+1)
                    printed_count = 1
                    
                sess.run(training_operation_small, feed_dict={x: batch_x, y: batch_y})
            
        validation_accuracy = evaluate(X_validation, y_validation)
        print("EPOCH {} ...".format(i+1))
        print("Validation Accuracy = {:.3f}".format(validation_accuracy))
        print()
        
    saver.save(sess, './lenet')
    print("Model saved")
```

    Training...
    
    This is EPOCH 1
    EPOCH 1 ...
    Validation Accuracy = 0.767
    
    This is EPOCH 2
    EPOCH 2 ...
    Validation Accuracy = 0.849
    
    This is EPOCH 3
    EPOCH 3 ...
    Validation Accuracy = 0.873
    
    This is EPOCH 4
    EPOCH 4 ...
    Validation Accuracy = 0.892
    
    This is EPOCH 5
    EPOCH 5 ...
    Validation Accuracy = 0.899
    
    This is EPOCH 6
    EPOCH 6 ...
    Validation Accuracy = 0.895
    
    This is EPOCH 7
    EPOCH 7 ...
    Validation Accuracy = 0.902
    
    This is EPOCH 8
    EPOCH 8 ...
    Validation Accuracy = 0.917
    
    This is EPOCH 9
    EPOCH 9 ...
    Validation Accuracy = 0.908
    
    This is EPOCH 10
    EPOCH 10 ...
    Validation Accuracy = 0.920
    
    This is EPOCH 11
    EPOCH 11 ...
    Validation Accuracy = 0.926
    
    This is EPOCH 12
    EPOCH 12 ...
    Validation Accuracy = 0.917
    
    This is EPOCH 13
    EPOCH 13 ...
    Validation Accuracy = 0.913
    
    This is EPOCH 14
    EPOCH 14 ...
    Validation Accuracy = 0.927
    
    This is EPOCH 15
    EPOCH 15 ...
    Validation Accuracy = 0.911
    
    This is EPOCH 16
    EPOCH 16 ...
    Validation Accuracy = 0.925
    
    This is EPOCH 17
    EPOCH 17 ...
    Validation Accuracy = 0.916
    
    This is EPOCH 18
    EPOCH 18 ...
    Validation Accuracy = 0.919
    
    This is EPOCH 19
    EPOCH 19 ...
    Validation Accuracy = 0.925
    
    This is EPOCH 20
    EPOCH 20 ...
    Validation Accuracy = 0.918
    
    This is EPOCH 21
    EPOCH 21 ...
    Validation Accuracy = 0.932
    
    This is EPOCH 22
    EPOCH 22 ...
    Validation Accuracy = 0.930
    
    This is EPOCH 23
    EPOCH 23 ...
    Validation Accuracy = 0.921
    
    This is EPOCH 24
    EPOCH 24 ...
    Validation Accuracy = 0.919
    
    This is EPOCH 25
    EPOCH 25 ...
    Validation Accuracy = 0.924
    
    This is EPOCH 26
    EPOCH 26 ...
    Validation Accuracy = 0.924
    
    Small learning rate: EPOCH 27
    EPOCH 27 ...
    Validation Accuracy = 0.940
    
    Small learning rate: EPOCH 28
    EPOCH 28 ...
    Validation Accuracy = 0.943
    
    Small learning rate: EPOCH 29
    EPOCH 29 ...
    Validation Accuracy = 0.943
    
    Small learning rate: EPOCH 30
    EPOCH 30 ...
    Validation Accuracy = 0.942
    
    Model saved


### Training Accuracy


```python
with tf.Session() as sess:
    saver.restore(sess, tf.train.latest_checkpoint('.'))

    test_accuracy = evaluate(X_train, y_train)
    print("Train Accuracy = {:.3f}".format(test_accuracy))
```

    Train Accuracy = 1.000


### Test the Model


```python
with tf.Session() as sess:
    saver.restore(sess, tf.train.latest_checkpoint('.'))

    test_accuracy = evaluate(X_test, y_test)
    print("Test Accuracy = {:.3f}".format(test_accuracy))
```

    Test Accuracy = 0.931


---

## Step 3: Test a Model on New Images

To give yourself more insight into how your model is working, download at least five pictures of German traffic signs from the web and use your model to predict the traffic sign type.

You may find `signnames.csv` useful as it contains mappings from the class id (integer) to the actual sign name.

### Load and Output the Images


```python
### Load the images and plot them here.
### Feel free to use as many code cells as needed.
import matplotlib.image as mpimg
import numpy as np

pic_1 = mpimg.imread('0_speed_limit_20kmh.jpg')

%matplotlib inline
plt.figure(figsize=(1,1))
plt.imshow(pic_1)
plt.show()

print(pic_1.shape)
print(type(pic_1))
```


![png](output_32_0.png)


    (32, 32, 3)
    <class 'numpy.ndarray'>



```python
pic_2 = mpimg.imread('3_speed_limit_60kmh.jpg')

%matplotlib inline
plt.figure(figsize=(1,1))
plt.imshow(pic_2)
plt.show()

pic_3 = mpimg.imread('9_no_passing.jpg')
plt.figure(figsize=(1,1))
plt.imshow(pic_3)
plt.show()

pic_4 = mpimg.imread('14_stop.jpg')
plt.figure(figsize=(1,1))
plt.imshow(pic_4)
plt.show()

pic_5 = mpimg.imread('23_slippery_road.jpg')
plt.figure(figsize=(1,1))
plt.imshow(pic_5)
plt.show()
```


![png](output_33_0.png)



![png](output_33_1.png)



![png](output_33_2.png)



![png](output_33_3.png)



```python
#creating an array with all the new pictures
new_pics = np.array([pic_1, pic_2, pic_3, pic_4, pic_5])
new_labels = np.array([0, 3, 9, 14, 23])
print("Shape of the picture array: ", new_pics.shape)
print("Type of the picture array: ", type(new_pics))
print("Shape of the label array: ", new_labels.shape)
print("Type of the label array: ", type(new_labels))
```

    Shape of the picture array:  (5, 32, 32, 3)
    Type of the picture array:  <class 'numpy.ndarray'>
    Shape of the label array:  (5,)
    Type of the label array:  <class 'numpy.ndarray'>



```python
# normalizing the pictures in the new picture array
new_pics = normalize(new_pics)
```

### Predict the Sign Type for Each Image


```python
### Run the predictions here and use the model to output the prediction for each image.
### Make sure to pre-process the images with the same pre-processing pipeline used earlier.
### Feel free to use as many code cells as needed.
# Evaluate the loss and accuracy of the model for a given dataset.

with tf.Session() as sess:
    saver.restore(sess, tf.train.latest_checkpoint('.'))

    test_accuracy = evaluate(new_pics, new_labels)
    print("Test Accuracy = {:.3f}".format(test_accuracy))
```

    Test Accuracy = 0.800


### Analyze Performance


```python
### Calculate the accuracy for these 5 new images. 
### For example, if the model predicted 1 out of 5 signs correctly, it's 20% accurate on these new images.
```


```python
def evaluate_high_level(X_data, y_data):
    num_examples = len(X_data)
    total_accuracy = 0
    sess = tf.get_default_session()
    for offset in range(0, num_examples, BATCH_SIZE):
        batch_x, batch_y = X_data[offset:offset+BATCH_SIZE], y_data[offset:offset+BATCH_SIZE]
        accuracy = sess.run(accuracy_operation, feed_dict={x: batch_x, y: batch_y})
        total_accuracy += (accuracy * len(batch_x))
        prediction = sess.run(correct_prediction, feed_dict={x: batch_x, y: batch_y})
        print("Model accuracy:", prediction)
        soft_entropy = sess.run(cross_entropy, feed_dict={x: batch_x, y: batch_y})
        print("Loss is: ", soft_entropy)
        results = sess.run(logits, feed_dict = {x: batch_x})

    return total_accuracy / num_examples
```


```python
### Run the predictions here and use the model to output the prediction for each image.
### Make sure to pre-process the images with the same pre-processing pipeline used earlier.
### Feel free to use as many code cells as needed.
# Evaluate the loss and accuracy of the model for a given dataset.

with tf.Session() as sess:
    saver.restore(sess, tf.train.latest_checkpoint('.'))

    test_accuracy = evaluate_high_level(new_pics, new_labels)
    print("Test Accuracy = {:.3f}".format(test_accuracy))
```

    Model accuracy: [ True  True  True  True False]
    Loss is:  [  4.64450713e-04   6.03612803e-04   2.12190280e-05   0.00000000e+00
       3.08041716e+00]
    Test Accuracy = 0.800


### Output Top 5 Softmax Probabilities For Each Image Found on the Web


```python
def evaluate_detailed(X_data, y_data):
    num_examples = len(X_data)
    total_accuracy = 0
    sess = tf.get_default_session()
    for offset in range(0, num_examples, BATCH_SIZE):
        batch_x, batch_y = X_data[offset:offset+BATCH_SIZE], y_data[offset:offset+BATCH_SIZE]
        accuracy = sess.run(accuracy_operation, feed_dict={x: batch_x, y: batch_y})
        total_accuracy += (accuracy * len(batch_x))
        prediction = sess.run(correct_prediction, feed_dict={x: batch_x, y: batch_y})

        soft_entropy = sess.run(cross_entropy, feed_dict={x: batch_x, y: batch_y})

        results = sess.run(logits, feed_dict = {x: batch_x})
        print("Logits are:", results[0:2])
        print("[...]")
        print(results[4])

        final = sess.run(tf.nn.softmax(results))
        print("\nProbabilities are:", final)
        top_5 = sess.run(tf.nn.top_k(final, k=5))
        print("\nTop probabilities are:", top_5)
    return total_accuracy / num_examples
```

For each of the new images, print out the model's softmax probabilities to show the **certainty** of the model's predictions (limit the output to the top 5 probabilities for each image). [`tf.nn.top_k`](https://www.tensorflow.org/versions/r0.12/api_docs/python/nn.html#top_k) could prove helpful here. 

The example below demonstrates how tf.nn.top_k can be used to find the top k predictions for each image.

`tf.nn.top_k` will return the values and indices (class ids) of the top k predictions. So if k=3, for each sign, it'll return the 3 largest probabilities (out of a possible 43) and the correspoding class ids.

Take this numpy array as an example. The values in the array represent predictions. The array contains softmax probabilities for five candidate images with six possible classes. `tk.nn.top_k` is used to choose the three classes with the highest probability:

```
# (5, 6) array
a = np.array([[ 0.24879643,  0.07032244,  0.12641572,  0.34763842,  0.07893497,
         0.12789202],
       [ 0.28086119,  0.27569815,  0.08594638,  0.0178669 ,  0.18063401,
         0.15899337],
       [ 0.26076848,  0.23664738,  0.08020603,  0.07001922,  0.1134371 ,
         0.23892179],
       [ 0.11943333,  0.29198961,  0.02605103,  0.26234032,  0.1351348 ,
         0.16505091],
       [ 0.09561176,  0.34396535,  0.0643941 ,  0.16240774,  0.24206137,
         0.09155967]])
```

Running it through `sess.run(tf.nn.top_k(tf.constant(a), k=3))` produces:

```
TopKV2(values=array([[ 0.34763842,  0.24879643,  0.12789202],
       [ 0.28086119,  0.27569815,  0.18063401],
       [ 0.26076848,  0.23892179,  0.23664738],
       [ 0.29198961,  0.26234032,  0.16505091],
       [ 0.34396535,  0.24206137,  0.16240774]]), indices=array([[3, 0, 5],
       [0, 1, 4],
       [0, 5, 1],
       [1, 3, 5],
       [1, 4, 3]], dtype=int32))
```

Looking just at the first row we get `[ 0.34763842,  0.24879643,  0.12789202]`, you can confirm these are the 3 largest probabilities in `a`. You'll also notice `[3, 0, 5]` are the corresponding indices.


```python
### Run the predictions here and use the model to output the prediction for each image.
### Make sure to pre-process the images with the same pre-processing pipeline used earlier.
### Feel free to use as many code cells as needed.
# Evaluate the loss and accuracy of the model for a given dataset.

with tf.Session() as sess:
    saver.restore(sess, tf.train.latest_checkpoint('.'))

    test_accuracy = evaluate_detailed(new_pics, new_labels)
print("\nList of correct labels:\n", new_labels)
```

    Logits are: [[  44.88630676   37.21177673  -21.66762733  -47.72222137   22.0649662
        10.37674427   -9.67597866  -12.32123375   -6.67182016  -62.17993546
       -35.09745026  -40.36177063  -62.1362114   -82.18600464  -43.27279663
       -37.47757721  -37.46923065  -33.89438629   -3.71460509  -52.04966354
        -6.20784426  -40.54773331  -49.66146469  -26.18574333  -22.89234543
       -43.48011017  -48.8201561   -39.4630127   -41.1484375     1.0578264
       -42.03946304  -14.10147095  -26.33756065  -26.94042397  -61.93175125
       -37.1951561   -57.56845093  -21.05101585  -29.6577282   -46.89458847
        -7.83249855  -45.19423294  -27.08935928]
     [ -46.93860245   10.5608511    59.22833633   66.64057922  -42.50639343
        44.69357681  -20.32196808  -34.59162903   -6.39392376  -35.95347977
       -39.30615234  -41.50081253  -73.85321045  -45.98867798  -43.99225235
        -0.73698741  -61.57890701  -79.45085907  -48.93322372  -55.32754517
       -35.87707901  -38.68273163  -90.43432617  -59.86635971  -85.97419739
       -45.58368301  -92.45413971  -36.85820007   -9.91635323  -11.92577267
       -69.88926697   16.06489944  -36.4822998   -60.3837738   -53.80192566
       -66.29214478  -39.42381287 -126.07836914  -21.47787476  -75.21773529
       -67.01767731  -81.23983765  -57.98195648]]
    [...]
    [ -8.45384369e+01  -4.23521500e+01  -3.74863358e+01  -2.31615448e+01
      -1.09604225e+02  -8.73151112e+00  -7.59845591e+00  -6.60760117e+01
      -1.01652481e+02  -3.31775475e+01   8.87553978e+00   1.35793238e+01
      -5.90093689e+01  -1.05034737e+02  -6.51409225e+01  -1.27654083e+02
      -3.68190231e+01  -5.71355743e+01  -3.21110840e+01   2.45405617e+01
       9.80953425e-02   2.90805969e+01  -8.87738571e+01   2.60944843e+01
      -4.52128487e+01  -1.14862430e+00  -5.41104813e+01  -5.93073425e+01
      -4.50227776e+01  -2.41782608e+01   4.72726107e-01   2.58035069e+01
      -6.53893585e+01  -5.52461205e+01  -6.49894180e+01  -6.91086807e+01
      -5.49671669e+01  -8.09333038e+01  -8.38262405e+01  -9.68060226e+01
      -6.04812355e+01  -3.14866848e+01  -4.46202126e+01]
    
    Probabilities are: [[  9.99535680e-01   4.64293116e-04   1.24678852e-29   0.00000000e+00
        1.22635443e-10   1.02916578e-15   2.01232639e-24   1.42849361e-25
        4.05870671e-23   0.00000000e+00   1.83355523e-35   9.48481197e-38
        0.00000000e+00   0.00000000e+00   0.00000000e+00   1.69675047e-36
        1.71097188e-36   6.10629826e-35   7.81072210e-22   0.00000000e+00
        6.45491747e-23   7.87531250e-38   0.00000000e+00   1.36018602e-31
        3.66354908e-30   0.00000000e+00   0.00000000e+00   2.32999120e-37
        4.31900393e-38   9.23275671e-20   1.77181257e-38   2.40841854e-26
        1.16859726e-31   6.39508541e-32   0.00000000e+00   2.25045466e-36
        0.00000000e+00   2.30984121e-29   4.22410222e-33   0.00000000e+00
        1.27148987e-23   0.00000000e+00   5.51017444e-32]
     [  0.00000000e+00   4.41186091e-25   6.03450520e-04   9.99396563e-01
        0.00000000e+00   2.93951585e-10   1.70758924e-38   0.00000000e+00
        1.91098574e-32   0.00000000e+00   0.00000000e+00   0.00000000e+00
        0.00000000e+00   0.00000000e+00   0.00000000e+00   5.47058595e-30
        0.00000000e+00   0.00000000e+00   0.00000000e+00   0.00000000e+00
        0.00000000e+00   0.00000000e+00   0.00000000e+00   0.00000000e+00
        0.00000000e+00   0.00000000e+00   0.00000000e+00   0.00000000e+00
        5.64267916e-34   7.56492030e-35   0.00000000e+00   1.08392492e-22
        0.00000000e+00   0.00000000e+00   0.00000000e+00   0.00000000e+00
        0.00000000e+00   0.00000000e+00   0.00000000e+00   0.00000000e+00
        0.00000000e+00   0.00000000e+00   0.00000000e+00]
     [  0.00000000e+00   0.00000000e+00   0.00000000e+00   0.00000000e+00
        0.00000000e+00   0.00000000e+00   0.00000000e+00   0.00000000e+00
        0.00000000e+00   9.99978781e-01   6.26529956e-17   0.00000000e+00
        1.68700605e-36   8.54179696e-38   0.00000000e+00   0.00000000e+00
        1.21576397e-20   0.00000000e+00   0.00000000e+00   1.42903573e-23
        2.14796293e-16   0.00000000e+00   0.00000000e+00   1.37510230e-24
        0.00000000e+00   1.68814087e-34   0.00000000e+00   0.00000000e+00
        5.25720726e-17   0.00000000e+00   6.43773380e-30   0.00000000e+00
        1.09910867e-37   0.00000000e+00   3.97264067e-29   1.95822328e-21
        0.00000000e+00   2.06304912e-35   0.00000000e+00   0.00000000e+00
        2.23511449e-30   2.11810493e-05   2.39141385e-23]
     [  2.20404518e-38   1.88535879e-28   4.37377569e-25   1.15089307e-13
        1.15869993e-34   1.61987361e-25   1.13125444e-34   0.00000000e+00
        2.72815421e-35   8.67334393e-32   7.15369149e-30   4.88355483e-36
        3.55511838e-27   8.84983298e-27   1.00000000e+00   5.85030922e-23
        0.00000000e+00   8.91531309e-31   0.00000000e+00   0.00000000e+00
        0.00000000e+00   9.69016817e-35   0.00000000e+00   0.00000000e+00
        0.00000000e+00   5.45617014e-37   5.03990598e-27   0.00000000e+00
        3.85872840e-38   4.17639401e-28   1.42832149e-35   0.00000000e+00
        4.85604870e-26   0.00000000e+00   0.00000000e+00   0.00000000e+00
        0.00000000e+00   0.00000000e+00   2.62685019e-31   0.00000000e+00
        0.00000000e+00   0.00000000e+00   0.00000000e+00]
     [  0.00000000e+00   8.63368568e-32   1.12044999e-29   1.86453333e-23
        0.00000000e+00   3.44710513e-17   1.07036814e-16   0.00000000e+00
        0.00000000e+00   8.33058397e-28   1.52791502e-09   1.68626812e-07
        0.00000000e+00   0.00000000e+00   0.00000000e+00   0.00000000e+00
        2.18374877e-29   3.27971860e-38   2.42010758e-27   9.71251633e-03
        2.35560974e-13   9.10005510e-01   0.00000000e+00   4.59400862e-02
        4.94096973e-33   6.77111158e-14   6.75488279e-37   0.00000000e+00
        5.97524533e-33   6.74552830e-24   3.42613036e-13   3.43417078e-02
        0.00000000e+00   2.16977323e-37   0.00000000e+00   0.00000000e+00
        2.86791089e-37   0.00000000e+00   0.00000000e+00   0.00000000e+00
        1.15567607e-39   4.51863186e-27   8.93698086e-33]]
    
    Top probabilities are: TopKV2(values=array([[  9.99535680e-01,   4.64293116e-04,   1.22635443e-10,
              1.02916578e-15,   9.23275671e-20],
           [  9.99396563e-01,   6.03450520e-04,   2.93951585e-10,
              1.08392492e-22,   4.41186091e-25],
           [  9.99978781e-01,   2.11810493e-05,   2.14796293e-16,
              6.26529956e-17,   5.25720726e-17],
           [  1.00000000e+00,   1.15089307e-13,   5.85030922e-23,
              4.37377569e-25,   1.61987361e-25],
           [  9.10005510e-01,   4.59400862e-02,   3.43417078e-02,
              9.71251633e-03,   1.68626812e-07]], dtype=float32), indices=array([[ 0,  1,  4,  5, 29],
           [ 3,  2,  5, 31,  1],
           [ 9, 41, 20, 10, 28],
           [14,  3, 15,  2,  5],
           [21, 23, 31, 19, 11]], dtype=int32))
    
    List of correct labels:
     [ 0  3  9 14 23]


### Project Writeup

Once you have completed the code implementation, document your results in a project writeup using this [template](https://github.com/udacity/CarND-Traffic-Sign-Classifier-Project/blob/master/writeup_template.md) as a guide. The writeup can be in a markdown or pdf file. 

> **Note**: Once you have completed all of the code implementations and successfully answered each question above, you may finalize your work by exporting the iPython Notebook as an HTML document. You can do this by using the menu above and navigating to  \n",
    "**File -> Download as -> HTML (.html)**. Include the finished document along with this notebook as your submission.
